console.log(Calculadora.somar(5).potencia(2, 8).resultado)
Calculadora.zerar().somar(2, 3).somar(3).log()